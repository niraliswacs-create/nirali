"""
Streamlit RAG App: Ask questions about a PDF using Gemini + Faiss.

Workflow:
1. User enters their Gemini API key in the sidebar.
2. User uploads a PDF.
3. On "Process PDF": extract text from the first page only, split into
   fixed-size chunks, embed each chunk, and store the embeddings in a
   Faiss index (built once per uploaded PDF, then reused).
4. User types a question.
5. On "Ask": embed the query, retrieve the top-3 most similar chunks,
   augment the prompt with them, send it to Gemini, and display both
   the answer and the retrieved chunks (for transparency).
6. If the answer isn't in the document, the model is instructed to
   respond "I do not know" instead of guessing.
"""

import numpy as np
import faiss
import streamlit as st
from pypdf import PdfReader
from google import genai
from google.genai import types

EMBEDDING_MODEL = "models/text-embedding-004"
GENERATION_MODEL = "gemini-2.5-flash"
CHUNK_SIZE = 500       # characters per chunk (fixed-size chunking)
CHUNK_OVERLAP = 50     # overlap between consecutive chunks
TOP_K = 3              # number of chunks retrieved per question


# --------------------------------------------------------------------------
# Helper functions
# --------------------------------------------------------------------------

def extract_first_page_text(uploaded_file) -> str:
    """Extract text from the first page of the uploaded PDF only."""
    reader = PdfReader(uploaded_file)
    if len(reader.pages) == 0:
        return ""
    return reader.pages[0].extract_text() or ""


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into fixed-size, overlapping chunks."""
    chunks = []
    start = 0
    text_len = len(text)
    while start < text_len:
        end = min(start + chunk_size, text_len)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


def embed_texts(client: genai.Client, texts: list[str]) -> np.ndarray:
    """Create embeddings for a list of texts, returned as a float32 numpy array."""
    result = client.models.embed_content(model=EMBEDDING_MODEL, contents=texts)
    vectors = [e.values for e in result.embeddings]
    return np.array(vectors, dtype="float32")


def build_faiss_index(embeddings: np.ndarray) -> faiss.IndexFlatL2:
    """Build a flat L2 Faiss index from an array of embeddings."""
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    return index


def retrieve_top_chunks(client: genai.Client, query: str, index: faiss.IndexFlatL2,
                         chunks: list[str], k: int = TOP_K) -> list[str]:
    """Embed the query and retrieve the k most similar chunks from the index."""
    query_vector = embed_texts(client, [query])
    _, indices = index.search(query_vector, k)
    return [chunks[i] for i in indices[0] if 0 <= i < len(chunks)]


def generate_answer(client: genai.Client, query: str, context_chunks: list[str]) -> str:
    """Send an augmented (RAG) prompt to Gemini and return the answer."""
    context = "\n\n---\n\n".join(context_chunks)
    prompt = f"""Answer the question using ONLY the context below.
If the answer is not present in the context, respond exactly with: "I do not know".

Context:
{context}

Question: {query}

Answer:"""

    config = types.GenerateContentConfig(temperature=0.2, max_output_tokens=512)
    response = client.models.generate_content(
        model=GENERATION_MODEL,
        contents=prompt,
        config=config,
    )
    return response.text


# --------------------------------------------------------------------------
# Streamlit UI
# --------------------------------------------------------------------------

st.set_page_config(page_title="PDF Q&A with Gemini", page_icon="📄", layout="wide")
st.title("📄 Ask Questions About Your PDF (RAG + Gemini)")

# --- Sidebar: API key ---
api_key = st.sidebar.text_input("Enter your Gemini API key", type="password")

# Session state holds the processed index/chunks so they persist across
# reruns and are NOT rebuilt on every "Ask" click.
if "index" not in st.session_state:
    st.session_state.index = None
    st.session_state.chunks = None
    st.session_state.pdf_processed = False

# --- File upload + processing ---
uploaded_pdf = st.file_uploader("Upload a PDF", type=["pdf"])

if uploaded_pdf is not None and api_key:
    if st.button("Process PDF"):
        with st.spinner("Extracting text, creating embeddings, and building the index..."):
            client = genai.Client(api_key=api_key)

            first_page_text = extract_first_page_text(uploaded_pdf)
            if not first_page_text.strip():
                st.error("No extractable text found on the first page of this PDF.")
            else:
                chunks = chunk_text(first_page_text)
                embeddings = embed_texts(client, chunks)
                index = build_faiss_index(embeddings)

                st.session_state.index = index
                st.session_state.chunks = chunks
                st.session_state.pdf_processed = True

        if st.session_state.pdf_processed:
            st.success(f"PDF processed into {len(st.session_state.chunks)} chunks. Ready for questions!")

# --- Question + answer ---
if st.session_state.pdf_processed:
    st.divider()
    question = st.text_input("Ask a question about the document")

    if st.button("Ask") and question:
        with st.spinner("Retrieving relevant context and generating an answer..."):
            client = genai.Client(api_key=api_key)
            top_chunks = retrieve_top_chunks(
                client, question, st.session_state.index, st.session_state.chunks
            )
            answer = generate_answer(client, question, top_chunks)

        st.subheader("Answer")
        st.write(answer)

        with st.expander("Retrieved chunks (for transparency)"):
            for i, chunk in enumerate(top_chunks, start=1):
                st.markdown(f"**Chunk {i}:**")
                st.write(chunk)
                st.divider()
elif uploaded_pdf is not None and not api_key:
    st.warning("Enter your Gemini API key in the sidebar to process the PDF.")
