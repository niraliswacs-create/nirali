//Viral Science www.viralsciencecreativity.com www.youtube.com/c/viralscience
//WaterLevel Sensor Automatic Water Filling
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x3F, 16, 2); // LCD HEX address 0x3F -- change according to yours
 
int val = 0;  
int watersensor = A0; 
int Motor = 2;
void setup() { 
 Serial.begin(9600);
  lcd.begin(); 
  pinMode(Motor,OUTPUT);
  digitalWrite(Motor,LOW);
  // Print a message to the LCD. 
  lcd.print("WATER LEVEL: "); 
} 
  
void loop() { 
  val = analogRead(watersensor);
   Serial.println(val);
  lcd.setCursor(13,0);
  lcd.println(val);
  lcd.setCursor(0, 1); 
    
  
  if (val<=100)
  { 
    lcd.println("Empty "); 
    digitalWrite(Motor,HIGH);
  } 
  else if (val>100 && val<=450)
  { 
    lcd.println("Low ");
    digitalWrite(Motor,HIGH); 
  } 
  else if (val>450 && val<=500)
  { 
    lcd.println("Medium "); 
  } 
  else if (val>500)
  { 
    lcd.println("High ");
    digitalWrite(Motor,LOW); 
  }
  delay(1000); 
}
